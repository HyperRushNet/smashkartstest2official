'use strict';

function showInterstitial(audioOn, interstitialType, interstitialName)
{
}

function tryInitRewardedInterstitial(audioOn)
{
}

function tryShowRewardedInterstitial(audioOn)
{
}
