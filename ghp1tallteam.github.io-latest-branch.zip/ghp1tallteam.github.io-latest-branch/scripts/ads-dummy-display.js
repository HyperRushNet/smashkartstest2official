'use strict';

///////////////////////////
function requestLoadingAd()
{
}

function hideLoadingAd()
{
}

function requestMainMenuAd()
{
}

function hideMainMenuAd()
{
}

function requestWinCeremonyAd()
{
}

function hideWinCeremonyAd()
{
}

function requestSpectateAd()
{
}

function hideSpectateAd()
{
}

function requestDeathAd()
{
}

function hideDeathAd()
{
}

function requestOffCanvasAd(adResArrayToHide, adTagIdToShow)
{
}

function hideOffCanvasAds(adResArray)
{
}
